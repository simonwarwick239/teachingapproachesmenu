{
  "items": [
    {"label": "Michelle Pfeiffer",
     "type": "Celebrity",
     "tags": ["female", "American"]
    },
    {"label": "Keanu Reeves",
     "type": "Celebrity",
     "tags": ["male", "American"]
    },
    {"label": "Brigitte Bardot",
     "type": "Celebrity",
     "tags": ["female", "French", "dead"]
    }
]
}
