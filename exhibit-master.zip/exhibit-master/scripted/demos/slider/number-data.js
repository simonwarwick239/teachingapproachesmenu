{
    "types": {
        "Number": {
            "pluralLabel": "Numbers"
        }
    },
    "properties": {
        "number": {
            "valueType": "number"
        },
		"two": {
	    	"valueType": "number"
		}
    },
    "items": [
		{ "type": "Number",
		  "label": "Small",
		  "number": 1,
		  "two": 4
		},
		{ "type": "Number",
		  "label": "Middle",
		  "number": 5,
		  "two": -2
		},
		{ "type": "Number",
		  "label": "Other Middle",
		  "number": 5,
		  "two": 0
		},
		{ "type": "Number",
		  "label": "Middlish",
		  "number": 6,
		  "two": 8
		},
		{ "type": "Number",
		  "label": "Large",
		  "number": 20,
		  "two": -10
		}
    ]
}

