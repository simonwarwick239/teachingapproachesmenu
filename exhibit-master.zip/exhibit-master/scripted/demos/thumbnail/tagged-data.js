{
  "items": [
    {"label": "Michelle Pfeiffer",
     "type": "Celebrity",
     "tags": ["female", "American"]
    },
    {"label": "Keanu Reeves",
     "type": "Celebrity",
     "tags": ["male", "American"]
    },
    {"label": "Brigitte Bardot",
     "type": "Celebrity",
     "tags": ["female", "French", "dead"]
    },
    {"label": "Bruce Lee",
     "type": "Celebrity",
     "tags": ["male", "Hong Kong", "dead"]
    },
    {"label": "Bruce Boxleitner",
     "type": "Celebrity",
     "tags": ["not so", "male", "American"]
    },
    {"label": "Incredible Hulk",
     "type": "Celebrity",
     "tags": ["fiction", "male", "American", "green"]
    },
    {"label": "John Doe",
     "type": "Celebrity",
     "tags": []
    },
    {"label": "Nelson Mandela",
     "type": "Celebrity",
     "tags": ["politician", "South African", "male"]
    },
    {"label": "Charlie Chaplin",
     "type": "Celebrity",
     "tags": ["male", "English", "dead"]
    }
]
}
