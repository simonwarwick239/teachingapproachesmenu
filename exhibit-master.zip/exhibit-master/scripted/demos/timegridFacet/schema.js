{
	"types": {
	    "Event": {
		"pluralLabel": "Events"
	    }
	},
	"properties": {
	    "start": {
		"valueType": "date"
	    },
            "end": {
                "valueType": "date"  
            },
	    "important": {
		"valueType": "boolean"
	    },
	    "display": {
		"valueType": "boolean"
	    }
	}
}