Exhibit.Localization.importExtensionLocale("de", {
    "%MapView.label": "Landkarte",
    "%MapView.tooltip": "Zeige diese Elemente auf einer Landkarte"
});
