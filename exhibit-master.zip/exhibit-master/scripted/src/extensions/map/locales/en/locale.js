Exhibit.Localization.importExtensionLocale("en", {
    "%MapView.label": "Map",
    "%MapView.tooltip": "View items on a map",
    "%MapView.error.remoteImage": "A map icon attempted to load a remote image (%1$s) which could not be completed due to browser security restrictions.  Either the remote host must enable CORS requests or you must host the image on the same host as this page; otherwise you'll end up relying on a Painter service."
});
