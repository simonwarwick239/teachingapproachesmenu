Exhibit.Localization.importExtensionLocale("fr", {
    "%MapView.label": "Carte",
    "%MapView.tooltip": "Voir les items sur une carte"
});
