Exhibit.Localization.importExtensionLocale("nl", {
    "%MapView.label": "Kaart",
    "%MapView.tooltip": "Bekijk items met een kaart"
});
