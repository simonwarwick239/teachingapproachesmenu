Exhibit.Localization.importExtensionLocale("sv", {
    "%MapView.label": "Karta",
    "%MapView.tooltip": "Visa på karta"
});
