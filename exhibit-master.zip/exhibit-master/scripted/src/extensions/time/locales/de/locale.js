Exhibit.Localization.importExtensionLocale("de", {
    "%TimelineView.label": "Zeitleiste",
    "%TimelineView.tooltip": "Zeige diese Elemente auf einer Zeitleiste"
});
