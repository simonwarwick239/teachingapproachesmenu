Exhibit.Localization.importExtensionLocale("en", {
    "%TimelineView.label": "Timeline",
    "%TimelineView.tooltip": "View items on a timeline"
});
