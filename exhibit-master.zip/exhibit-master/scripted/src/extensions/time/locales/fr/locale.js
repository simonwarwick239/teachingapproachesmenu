Exhibit.Localization.importExtensionLocale("fr", {
    "%TimelineView.label": "Ligne de temps",
    "%TimelineView.tooltip": "Voir les items sur une ligne de temps"
});
