Exhibit.Localization.importExtensionLocale("nl", {
    "%TimelineView.label": "Tijdlijn",
    "%TimelineView.tooltip": "Bekijk items op een tijdlijn"
});
