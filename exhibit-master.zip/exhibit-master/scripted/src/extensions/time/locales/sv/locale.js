Exhibit.Localization.importExtensionLocale("sv", {
    "%TimelineView.label": "Tidslinje",
    "%TimelineView.tooltip": "Visa på tidslinje"
});
