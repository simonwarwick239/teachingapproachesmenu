module("Exhibit.Database._LocalImpl");

test("prototype", function() {
    //expect();
});

test("createDatabase", function() {
    //expect();
});

test("loadData", function() {
    //expect();
});

test("loadTypes", function() {
    //expect();
});

test("loadProperties", function() {
    //expect();
});

test("loadItems", function() {
    //expect();
});

test("getType", function() {
    //expect();
});

test("getProperty", function() {
    //expect();
});

test("getAllProperties", function() {
    //expect();
});

test("getAllItems", function() {
    //expect();
});

test("getAllItemsCount", function() {
    //expect();
});

test("containsItem", function() {
    //expect();
});

test("getNamespaces", function() {
    //expect();
});

test("getObjects", function() {
    //expect();
});

test("getDistinctObjects", function() {
    //expect();
});

test("countDistinctObjects", function() {
    //expect();
});

test("getObjectsUnion", function() {
    //expect();
});

test("countDistinctObjectsUnion", function() {
    //expect();
});

test("getSubjects", function() {
    //expect();
});

test("countDistinctSubjects", function() {
    //expect();
});

test("getSubjectsUnion", function() {
    //expect();
});

test("countDistinctSubjectsUnion", function() {
    //expect();
});

test("getObject", function() {
    //expect();
});

test("getSubject", function() {
    //expect();
});

test("getForwardProperties", function() {
    //expect();
});

test("getBackwardProperties", function() {
    //expect();
});

test("getSubjectsInRange", function() {
    //expect();
});

test("getTypeIDs", function() {
    //expect();
});

test("addStatement", function() {
    //expect();
});

test("removeStatement", function() {
    //expect();
});

test("removeObjects", function() {
    //expect();
});

test("removeSubjects", function() {
    //expect();
});

test("removeAllStatements", function() {
    //expect();
});

test("getItem", function() {
    //expect();
});

test("addItem", function() {
    //expect();
});

test("editItem", function() {
    //expect();
});

test("removeItem", function() {
    //expect();
});

test("_loadLinks", function() {
    //expect();
});

test("_loadItem", function() {
    //expect();
});

test("_ensureTypeExists", function() {
    //expect();
});

test("_ensurePropertyExists", function() {
    //expect();
});

test("_indexFillSet", function() {
    //expect();
});

test("_indexCountDistinct", function() {
    //expect();
});

test("_get", function() {
    //expect();
});

test("_getUnion", function() {
    //expect();
});

test("_countDistinctUnion", function() {
    //expect();
});

test("_countDistinct", function() {
    //expect();
});

test("_getProperties", function() {
    //expect();
});
