module("Exhibit.Database._Property");

test("prototype", function() {
    //expect();
});

test("getID", function() {
    //expect();
});

test("getURI", function() {
    //expect();
});

test("getValueType", function() {
    //expect();
});

test("getLabel", function() {
    //expect();
});

test("getPluralLabel", function() {
    //expect();
});

test("getReverseLabel", function() {
    //expect();
});

test("getReversePluralLabel", function() {
    //expect();
});

test("getGroupingLabel", function() {
    //expect();
});

test("getGroupingPluralLabel", function() {
    //expect();
});

test("getOrigin", function() {
    //expect();
});

test("getRangeIndex", function() {
    //expect();
});

test("_onNewData", function() {
    //expect();
});

test("_buildRangeIndex", function() {
    //expect();
});
