module("Exhibit.Database._RangeIndex");

test("prototype", function() {
    //expect();
});

test("getCount", function() {
    //expect();
});

test("getMin", function() {
    //expect();
});

test("getMax", function() {
    //expect();
});

test("getRange", function() {
    //expect();
});

test("getSubjectsInRange", function() {
    //expect();
});

test("countRange", function() {
    //expect();
});

test("_indexOf", function() {
    //expect();
});
