module("Exhibit.Database._Type");

test("prototype", function() {
    //expect();
});

test("getID", function() {
    //expect();
});

test("getURI", function() {
    //expect();
});

test("getLabel", function() {
    //expect();
});

test("getOrigin", function() {
    //expect();
});

test("getProperty", function() {
    //expect();
});
