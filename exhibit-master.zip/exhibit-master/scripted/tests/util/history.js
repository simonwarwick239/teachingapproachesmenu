module("Exhibit.History");

test("register", function() {
    // expect();
});
